FREYA Revision 8 Sites 3D Project

Contents:
- index.html — integrated Sites-ready mission simulator with 3D-style visualization and all live controls
- FREYA_Engineering_Study_Revision_8_Fully_Integrated.pdf/.docx — integrated report

This package merges the Sites content with a single shared-parameter simulation model. All controls are visible and manually adjustable. The mission sequence table and telemetry table are populated from the same current scenario.
